const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["628979637540@s.whatsapp.net"]
global.nomerOwner = "628979637540"
global.nomorOwner = ['628979637540']
global.nameGEDE = "4KSANZZ"
global.namaDeveloper = "4KSANZZ"
global.namaBot = "4KSANZZ WhatsApp"
global.packname = ""
global.author = "Sticker By 4K SANZZ"
global.thumb = fs.readFileSync("./thumb.png")

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})

/*

Thanks To By 4KSANZZ
Base Ori By KirBotz
Ubah Nomor Owner?
Ganti Di File ./owner.json
Harap Jangan Jual Sc Ini
Karena Sc Ini Free Langsung Dari
Youtube : https://youtube.com/@kangbotwhatsapp

*/